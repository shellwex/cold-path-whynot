-- Welcome plugin: shows a personal, styled greeting in chat when a player enters the game.
-- Auto-loaded from core/server/plugins/ (no changes to plugins_manager needed).
--
-- Settings (server_settings.lua -> plugin):
--   welcome_banner = true|false   -- turn the greeting on/off (default: on)
--   commands_info                 -- list of {text = "..."}; shown as a command hint block
--   (the server name is taken from server_info.data.name)
--
-- The greeting is visible only to the joining player.

local M = {}

local api

-- Colors (supported by the chat: names or "r,g,b,a" floats)
local GOLD = "1.0,0.8,0.2,1"
local ICE = "0.55,0.85,1.0,1"
local GREY = "grey"
local WHITE = "white"

local function c(color, text)
	return "<color=" .. color .. ">" .. text .. "</color>"
end

local function send(client, text)
	api.call_function("chat_function", text, true, client)
end

-- Number of players who are currently in game
local function count_online()
	local n = 0
	for _, v in pairs(api.get_data("clients_data")) do
		if v.state == "in_game" then
			n = n + 1
		end
	end
	return n
end

-- Number of playable civilizations (same rule as the server list uses)
local function count_slots()
	local n = 0
	for _, land in pairs(game_data.lands) do
		if not land.defeated and land.name ~= "undeveloped_land" then
			n = n + 1
		end
	end
	return n
end

local function format_time(seconds)
	seconds = tonumber(seconds) or 0
	if seconds >= 60 then
		local m = math.floor(seconds / 60)
		local s = seconds % 60
		if s == 0 then
			return m .. " min"
		end
		return m .. " min " .. s .. " s"
	end
	return seconds .. " s"
end

local function greet(client)
	local cl_data = api.get_data("clients_data")[client]
	if not cl_data then
		return
	end

	local line = c(GOLD, "==============================")
	local settings_info = server_settings.server_info and server_settings.server_info.data or {}
	local server_name = settings_info.name or "Cold Path Server"

	send(client, line)
	send(client, c(GOLD, "  Welcome, ") .. c(WHITE, cl_data.name or "commander") .. c(GOLD, "!"))
	send(client, c(ICE, "  " .. server_name))
	send(client, line)

	-- Player's country
	local land = game_data.lands and game_data.lands[cl_data.civilization]
	if land then
		send(client, c(GREY, "  You lead: ") .. "|" .. land.name .. ",lands|")
	end

	-- Server status
	send(client, c(GREY, "  Players online: ") .. c(WHITE, count_online() .. " / " .. count_slots()))
	send(client, c(GREY, "  Turn time: ") .. c(WHITE, format_time(server_settings.time_to_turn)))
	local difficulty = server_settings.plugin and server_settings.plugin.difficulty
	if difficulty then
		send(client, c(GREY, "  AI difficulty: ") .. c(WHITE, difficulty))
	end

	-- Commands
	local commands = server_settings.plugin and server_settings.plugin.commands_info
	if commands and #commands > 0 then
		send(client, c(GOLD, "  Useful commands:"))
		for _, cmd in ipairs(commands) do
			if cmd.text then
				send(client, c(WHITE, "   " .. cmd.text))
			end
		end
	end

	-- Community link (hyperlinks plugin provides the "discord" id to the client)
	send(client, c(GREY, "  Community: ") .. "<color=lightblue><a=discord>Join our Discord</a></color>")
	send(client, c(GOLD, "  Good luck and have fun!"))
	send(client, line)
end

function M.init(_api)
	api = _api
end

function M.on_player_joined(client)
	if server_settings.plugin and server_settings.plugin.welcome_banner == false then
		return
	end
	-- Never let a cosmetic greeting break the join flow of other plugins
	local ok, err = pcall(greet, client)
	if not ok then
		log("plugin", "Welcome greeting error: ", err)
	end
end

return M
